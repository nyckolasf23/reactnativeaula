import React from "react";
import { Text } from 'react-native'

   function CompOficial(){
    return <Text>Componente #Oficial</Text>
}

  function Comp1(){
    return <Text>Componente 02</Text>
}

  function Comp2(){
    return <Text>Componente 03</Text>
}

export {Comp1, Comp2}
export default CompOficial