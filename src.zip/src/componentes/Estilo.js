import { StyleSheet } from 'react-native'

export default StyleSheet.create({
    txtGrande: {
        fontSize: 25
    }

})