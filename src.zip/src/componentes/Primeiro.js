import React from "react";
import { Text } from 'react-native'
import Estilo from "./Estilo";

export default () =>{
    // console.warn("Oi Novotec !!!")
    return(
 <Text style={Estilo.txtGrande}>Primeiro Componente</Text>
    )
}